This is a example of the use of SA-1 with Level ASM.

Apply in your ROM, level.asm together with sa1.asm and see what's happening.

Actually, it creates a simple counter in status bar and play a SFX when it's zeroed.
For this to become possible, it's necessary to copy some RAMs to I-RAM.