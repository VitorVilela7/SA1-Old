;;======================================;;
;; SA-1 coprocessor for SMW version 1.0 ;;
;;======================================;;

This patch install a coprocessor in your ROM called SA-1.
SA-1 is an improved version of the 5A22 (SNES CPU), where
has a 10.74 mHz clock and several new features to improve
the speed of your ROM. In total, SA-1 is about five times
faster than the SNES.

This patch is compatible with all modern emulators, including
ZSNES.

To install this patch, choose a freespace that is in banks
10-1F. I recommend installing on a clean ROM expanded in 1
or 2MB.

Before applying, open the patch and change the properties
!CXB, !DXB,!EXB and !FXB. These settings determine how the
space of the ROM will work.

For 1MB or 2MB SA-1 ROMs:

!CXB = $00
!DXB = $01
!EXB = $00
!FXB = $01

For 2.5MB - 4MB SA-1 ROMs:

!CXB = $00
!DXB = $01
!EXB = $02
!FXB = $03

For 6MB/8MB SA-1 ROMs:

Well.. Currently the patch supports 4MB + ROMs, but it is more
incompatible than you can imagine. For this reason, when I will
not go through the instructions on how to expand the ROM 6MB/8MB.

Once installed, open the ROM with Lunar Magic and press Shift
+ Page Down. If a message appears saying that the ROM has a
special chip, congratulations, the patch was installed
successfully!

;;======================================;;
;; Compatibility                        ;;
;;======================================;;

This is the downside of the story: Compatibility. Today the most
famous thing in leaving the ROM fast is FastROM, right? Well,
FastROM it changes all addresses for $80:8000-$FF:FFFF. The main
problem is that if you are using an SA-1 ROM of 4MB, $80:8000-$BF:FFFF
will map the third and fourth megabyte of ROM. Thus, crashes are
guaranteed. Not only patches, but their tools as well. Addmusic,
Sprite Tool, it is not compatible with SA-1 if they use FastROM or
do not move the addresses to the correct location.

The only way to fix is to leave only with 2MB ROM and put !EXB to $00
and !FXB to $01. This setting will mimic FastROM.

So, if you will use SA-1 for your project, leave a 2MB ROM for
the moment. If you are a developer, please add support for a 4/6/8MB
SA-1 ROMs.

Besides this problem, some old emulators will not emulate SA-1
correctly. An obvious example is the ZSNES, or did not notice
that Super Mario RPG freezes at random times or Kirby Super Star
showed sprites totally buggy in some places?

Anyway, this is not of much concern as the future all this will
be corrected.

;;======================================;;
;; Working with SA-1                    ;;
;;======================================;;

If you want to develop programs or patches with the SA-1, see
programming.txt

;;======================================;;
;; Credits                              ;;
;;======================================;;

Just wanted to thank you DiscoMan for helping me in the test battery.
No he would not know if SA-1 would work properly on high accuracy emulators.

Also want to thank the Alcaro detection code of ZSNES. Without this code,
SA-1 would not be compatible with ZSNES.

Bugs? Questions about the patch or on SA-1? Just send me a PM in SMW Central
(user id:8251)