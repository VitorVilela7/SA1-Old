==========================
= SA-1 Patch Version 1.0 =
==========================

This patch enable the use of a co-processor called SA-1 in your ROM.
It's the second processor which runs at 10.74 MHz and adds new possibilities of programming in your ROM.

=============
= Resources =
=============

 - An extra CPU running at 10.74 MHz and lots of resources to give your ROM a big boost.
It's 4 times faster than SNES CPU but both are executed at the same time, you can run
codes 5 times faster than normal with both CPUs.

 - HiROM. Don't ever have more problems with HiROM banks! You can access it
in banks $C0-$FF.

 - Lots of RAM. I-RAM and BW-RAM are onboard RAMs which are superiors to the WRAM and
they have massive sizes: 2kb (2048 bytes) for I-RAM and even 256kb (262.144 bytes)
of BW-RAM (this patch only supports 128kb (131.072 bytes))

 - Bitmap functions: With the DMA Character Conversion DMA, you can convert memory with
the bitmap datas for 2BPP, 4BPP or 8BPP SNES in the fly on VRAM.

 - Additional DMA Circuits: With SA-1, you can do DMA between ROM, I-RAM and BW-RAM very quickly.

 - Faster Math: You use only 5 cycles in 10 MHz to do any kind of multiplication or division
and still have also acumulative sum.

 - Byebye ExLoROM: SA-1 supports ROMs up to 8MB without any limitations.

============
= Warnings =
============

Before you apply, pay attention to some things:

1. Patch is now compatible ZSNES, unlike other versions.

2. The patch isn't compatible with FastROM, furthermore, the banks $40-$6F isn't ROM anymore.
To access the third and the fourth part of the ROM, access banks $80-$BF.

3. If your ROM have 2MB or less, you can alter !EXB definitions to $00 and !FXB to $01 to
make it compatible with FastROM, since $80-$BF will map the firt and second megabyte of ROM.

4. SA-1 won't add any performance in your ROM if you just apply sa1.asm.
SA-1 is a additional programmable CPU not a SNES CPU replacement.

5. Lunar Magic won't let you apply any FastROM patch or ExLOROM.
It detects SA-1 and auto-adjust. Furthermore, don't be afraid: If your ROM is bigger than
2MB, Lunar Magic will save every data above the 2nd megabyte, it doesn't matter if you're
or aren't using that function.

=============
= Emulators =
=============

BSNES - Emulates SA-1 perfectly without any problems. I recommend using it when you're programming
a code in SA-1 where it messes with it's registers. I don't sure, but some versions the speed is
always 10.74 MHz.

SNES9X - Emulates SA-1 correctly and basically supports every resource in the last version
(1.53). But in the previous versions including 1.43, there's lots of problems with emulation in SA-1.

ZSNES - Emulates SA-1. Now works with this patch, yeah, thank you Alcaro. Note that less functions
are supported and it's speed is always emulated at 5.37 MHz...

Others - Not Tested.

============
= Applying =
============

Before you apply, open sa1.asm and edit some definitions:

!Frespace - It's obvious, it's a freespace for your ROM. Don't apply above bank $3F!

!BWRAM - It's the size of BW-RAM in your ROM. The higher, more RAM/SRAM SA-1 will access. Valid Values:

$04 - 16 KB
$05 - 32 KB
$06 - 64 KB
$07 - 128 KB
$08 - 256 KB (doesn't work?)

!FreeRAM - It needs 14 bytes and it must stay at the banks $7E or $7F. I recommend
don't mess in this value, if a patch uses it, modify it's address!

!SaveMemory - I think you can't modify that, unless you want to chante the structure
of BW-RAM.

!CXB, !DXB, !EXB e !FXB - It's the map of the banks in ROM. It's a bit complicated
to explain but I'll try:

This values define what megabyte of your ROM will stay in a certain place.

!CXB is apply in banks $00-$1F $00-$1F (LoROM) and $C0-$CF (HiROM).
!DXB is $20-$3F (LoROM) and $D0-$DF (HiROM).
!EXB is $80-$9F (LoROM) and $E0-$EF (HiROM).
!FXB is $A0-$BF (LoROM) and $F0-$FF (HiROM).

combining values, you can customize the mapping of the ROM. Here's some examples:

1. FastROM compatibility

!CXB = $00
!DXB = $01
!EXB = $00
!FXB = $01

This will map the first and second megabyte in $00-$3F, $80-$BF in LoROM and $C0-$DF, $E0,$FF in HiROM.

2. Regular

!CXB = $00
!DXB = $01
!EXB = $02
!FXB = $03

With this you can access every megabyte in a 4MB ROM. In this case $80-$BF (and $E0-$FF)
will map the third and fourth megabyte of ROM.

Ultimately, every value represents one megabyte in ROM. Thanks to that, you can
even have a 8MB ROM!

OK, here's the question: How do I access everything? Simple! You can modify the values
in any moment in RAMs $2220-$2223! Note that if, you must add #$80, or only the
HiROM map will be affected.

===============
= Programming =
===============

Programming SA-1 is very simple, you just need to attention, patience and even some humor.

See library.asm for some examples.

IMPORTANT: Isn't possible to access the standard RAM of SNES, $7E-$7F. Don't even try.
You can only access I-RAM and BW-RAM. But before, you need to know about it:

I-RAM

In most modern CPUs, exists L1 and L2 cahe, right? Well, I-RAM works like a cache memory.
It runs to 10.74 MHz and has free access. If you want to work in a heavy code, I-RAM is
perfect for best performance.

I-RAM is mapped in $3000-$37FF in banks $00-$3F and $80-$BF in SNES CPU.
In SA-1 it's the same thing, except that $0000-$07FF is mapped too.

BW-RAM

BW-RAM is an interesting RAM. In addition to being faster (5.37 MHz) and being too large
(256KB depending the size of SRAM) and acts like a SRAM!

To access BW-RAM it's simple: It's mapped in banks $40-$4F. Because it can't fill this space,
it'll repeat if it gets out of range. You can access the first 8KB in RAM $7000-$7FFF
in banks $00-$3F and $80-$BF.

Now you know a bit about the RAMs, you must know how to execute a code with SA-1.
It's simple:

1. Put the pointer (24-bit) in RAMs $3080-$3082
2. JSL it to the FreeRAM. When the JSL occurs, a code generates a IRQ for the SA-1
and it jumps to the specific address.

There's a example code in the folder "example". Open and apply the level.asm together
with the sa1.asm in your ROM. In level105, there's a simple counter that plays a SFX
when it's zero'd and level106 show a example with parallel & interrupt SNES.

Besides that, there's a very interesting way to operate SA-1: Paralel Mode (in second plan).
With this mode, you can execute a code in background and you can use it indefinitely
without causing any slowdown. As a bonus, you have a excelent performance with it
because it's executed the same time with the SNES CPU.

Any question, send a PM for me, Vitor Vilela in SMW Central (UserID:8251)
- Document Translated by DiscoMan and updated by Vitor Vilela -