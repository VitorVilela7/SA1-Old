using System;
using System.IO;
using System.Text;
using System.Collections.Generic;


namespace Vilela {
	class Program {
		static readonly ushort[] smkdan = new ushort[] {
			0x0016, 0x001D, 0x0024, 0x002B, 0x0058, 0x005F, 0x0066, 0x006D, 0x009A, 0x00A1, 
			0x00A8, 0x00AF, 0x00DC, 0x00E3, 0x00EA, 0x00F1, 0x011E, 0x0125, 0x012C, 0x0133, 
			0x0160, 0x0167, 0x016E, 0x0175, 0x01A2, 0x01A9, 0x01B0, 0x01B7, 0x01E4, 0x01EB, 
			0x01F2, 0x01F9, 0x0226, 0x022D, 0x0234, 0x023B, 0x0268, 0x026F, 0x0276, 0x027D, 
			0x02AA, 0x02B1, 0x02B8, 0x02BF, 0x02EC, 0x02F3, 0x02FA, 0x0301, 0x032E, 0x0335, 
			0x033C, 0x0343, 0x0370, 0x0377, 0x037E, 0x0385, 0x03B2, 0x03B9, 0x03C0, 0x03C7, 
			0x03F4, 0x03FB, 0x0402, 0x0409, 0x0436, 0x043D, 0x0444, 0x044B, 0x0478, 0x047F, 
			0x0486, 0x048D, 0x04BA, 0x04C1, 0x04C8, 0x04CF, 0x04FC, 0x0503, 0x050A, 0x0511, 
			0x08D2, 0x08DB, 0x08E4, 0x08ED, 0x091C, 0x0925, 0x092E, 0x0937, 0x0966, 0x096F, 
			0x0978, 0x0981, 0x09B0, 0x09B9, 0x09C2, 0x09CB, 0x09FA, 0x0A03, 0x0A0C, 0x0A15, 
			0x0A44, 0x0A4D, 0x0A56, 0x0A5F, 0x0A8E, 0x0A97, 0x0AA0, 0x0AA9, 0x0AD8, 0x0AE1, 
			0x0AEA, 0x0AF3, 0x0B22, 0x0B2B, 0x0B34, 0x0B3D, 0x0B6C, 0x0B75, 0x0B7E, 0x0B87, 
			0x0BB6, 0x0BBF, 0x0BC8, 0x0BD1, 0x0C00, 0x0C09, 0x0C12, 0x0C1B, 0x0C4A, 0x0C53, 
			0x0C5C, 0x0C65, 0x0C94, 0x0C9D, 0x0CA6, 0x0CAF, 0x0CDE, 0x0CE7, 0x0CF0, 0x0CF9, 
			0x0D28, 0x0D31, 0x0D3A, 0x0D43, 0x0D72, 0x0D7B, 0x0D84, 0x0D8D, 0x0DBC, 0x0DC5, 
			0x0DCE, 0x0DD7, 0x0E06, 0x0E0F, 0x0E18, 0x0E21, 0x0E50, 0x0E59, 0x0E62, 0x0E6B, 
			0x12AA, 0x12B1, 0x12B8, 0x12BF, 0x12DA, 0x12E1, 0x12E8, 0x12EF, 0x130A, 0x1311, 
			0x1318, 0x131F, 0x133A, 0x1341, 0x1348, 0x134F, 0x136A, 0x1371, 0x1378, 0x137F, 
			0x139A, 0x13A1, 0x13A8, 0x13AF, 0x13CA, 0x13D1, 0x13D8, 0x13DF, 0x13FA, 0x1401, 
			0x1408, 0x140F, 0x142A, 0x1431, 0x1438, 0x143F, 0x145A, 0x1461, 0x1468, 0x146F, 
			0x148A, 0x1491, 0x1498, 0x149F, 0x14BA, 0x14C1, 0x14C8, 0x14CF, 0x14EA, 0x14F1, 
			0x14F8, 0x14FF, 0x151A, 0x1521, 0x1528, 0x152F, 0x154A, 0x1551, 0x1558, 0x155F, 
			0x157A, 0x1581, 0x1588, 0x158F, 0x15B0, 0x15B7, 0x15BE, 0x15C5, 0x15E0, 0x15E7, 
			0x15EE, 0x15F5, 0x1610, 0x1617, 0x161E, 0x1625, 0x1640, 0x1647, 0x164E, 0x1655, 
			0x1670, 0x1677, 0x167E, 0x1685, 0x16A0, 0x16A7, 0x16AE, 0x16B5, 0x16D0, 0x16D7, 
			0x16DE, 0x16E5, 0x1700, 0x1707, 0x170E, 0x1715, 0x1730, 0x1737, 0x173E, 0x1745, 
			0x1760, 0x1767, 0x176E, 0x1775, 0x1790, 0x1797, 0x179E, 0x17A5, 0x17C0, 0x17C7, 
			0x17CE, 0x17D5, 0x17F0, 0x17F7, 0x17FE, 0x1805, 0x1820, 0x1827, 0x182E, 0x1835, 
			0x1850, 0x1857, 0x185E, 0x1865, 0x1880, 0x1887, 0x188E, 0x1895, 0x18B3, 0x18BC, 
			0x18C5, 0x18CE, 0x18EB, 0x18F4, 0x18FD, 0x1906, 0x1923, 0x192C, 0x1935, 0x193E, 
			0x195B, 0x1964, 0x196D, 0x1976, 0x1993, 0x199C, 0x19A5, 0x19AE, 0x19CB, 0x19D4, 
			0x19DD, 0x19E6, 0x1A03, 0x1A0C, 0x1A15, 0x1A1E, 0x1A3B, 0x1A44, 0x1A4D, 0x1A56, 
			0x1A73, 0x1A7C, 0x1A85, 0x1A8E, 0x1AAB, 0x1AB4, 0x1ABD, 0x1AC6, 0x1AE3, 0x1AEC, 
			0x1AF5, 0x1AFE, 0x1B1B, 0x1B24, 0x1B2D, 0x1B36, 0x1B53, 0x1B5C, 0x1B65, 0x1B6E, 
			0x1B8B, 0x1B94, 0x1B9D, 0x1BA6, 0x1BC3, 0x1BCC, 0x1BD5, 0x1BDE, 0x1BFB, 0x1C04, 
			0x1C0D, 0x1C16, 0x1C39, 0x1C42, 0x1C4B, 0x1C54, 0x1C71, 0x1C7A, 0x1C83, 0x1C8C, 
			0x1CA9, 0x1CB2, 0x1CBB, 0x1CC4, 0x1CE1, 0x1CEA, 0x1CF3, 0x1CFC, 0x1D19, 0x1D22, 
			0x1D2B, 0x1D34, 0x1D51, 0x1D5A, 0x1D63, 0x1D6C, 0x1D89, 0x1D92, 0x1D9B, 0x1DA4, 
			0x1DC1, 0x1DCA, 0x1DD3, 0x1DDC, 0x1DF9, 0x1E02, 0x1E0B, 0x1E14, 0x1E31, 0x1E3A, 
			0x1E43, 0x1E4C, 0x1E69, 0x1E72, 0x1E7B, 0x1E84, 0x1EA1, 0x1EAA, 0x1EB3, 0x1EBC, 
			0x1ED9, 0x1EE2, 0x1EEB, 0x1EF4, 0x1F11, 0x1F1A, 0x1F23, 0x1F2C, 0x1F49, 0x1F52, 
			0x1F5B, 0x1F64, 0x1F81, 0x1F8A, 0x1F93, 0x1F9C, 0x1FB2, 0x1FB7, 0x1FBC, 0x1FC1, 
			0x1FD6, 0x1FDB, 0x1FE0, 0x1FE5, 0x1FFA, 0x1FFF, 0x2004, 0x2009, 0x201E, 0x2023, 
			0x2028, 0x202D, 0x2042, 0x2047, 0x204C, 0x2051, 0x2066, 0x206B, 0x2070, 0x2075, 
			0x208A, 0x208F, 0x2094, 0x2099, 0x20AE, 0x20B3, 0x20B8, 0x20BD, 0x20D2, 0x20D7, 
			0x20DC, 0x20E1, 0x20F6, 0x20FB, 0x2100, 0x2105, 0x211A, 0x211F, 0x2124, 0x2129, 
			0x213E, 0x2143, 0x2148, 0x214D, 0x2162, 0x2167, 0x216C, 0x2171, 0x2186, 0x218B, 
			0x2190, 0x2195, 0x21AA, 0x21AF, 0x21B4, 0x21B9, 0x21CE, 0x21D3, 0x21D8, 0x21DD, 
			0x21FD, 0x2202, 0x2207, 0x220C, 0x2221, 0x2226, 0x222B, 0x2230, 0x2245, 0x224A, 
			0x224F, 0x2254, 0x2269, 0x226E, 0x2273, 0x2278, 0x228D, 0x2292, 0x2297, 0x229C, 
			0x22B1, 0x22B6, 0x22BB, 0x22C0, 0x22D5, 0x22DA, 0x22DF, 0x22E4, 0x22F9, 0x22FE, 
			0x2303, 0x2308, 0x231D, 0x2322, 0x2327, 0x232C, 0x2341, 0x2346, 0x234B, 0x2350, 
			0x2365, 0x236A, 0x236F, 0x2374, 0x2389, 0x238E, 0x2393, 0x2398, 0x23AD, 0x23B2, 
			0x23B7, 0x23BC, 0x23D1, 0x23D6, 0x23DB, 0x23E0, 0x23F5, 0x23FA, 0x23FF, 0x2404, 
			0x2419, 0x241E, 0x2423, 0x2428, 0x2438, 0x247F, 0x25A3, 0x25C6, 0x27D5, 0x27E0, 
			0x2849, 0x2854, 0x28BD, 0x2926, 0x298F, 0x29F8, 0x2AEF, 0x2C8D, 0x2CA3, 0x2D38, 
			0x2D4E, 0x2DAC, 0x2DBD, 0x2DD3, 0x2E66, 0x2ECF, 0x2EE0, 0x2EF6, 0x2F52, 0x3000, 
			0x301F, 0x303C, 0x3087, 0x30B0, 0x3168, 0x316E, 0x3174, 0x317A, 0x3180, 0x3186, 
			0x318C, 0x3192, 0x319D, 0x31B6, 0x3202, 0x32B5, 0x32CB, 0x32D0, 0x32DD, 0x32E6, 
			0x32EB, 0x32F5, 0x32FB, 0x3300, 0x3310, 0x3319, 0x331E, 0x332E, 0x333A, 0x3344, 
			0x3351, 0x335D, 0x3367, 0x3373, 0x3389, 0x338E, 0x339B, 0x33A4, 0x33A9, 0x33B3, 
			0x33B9, 0x33BE, 0x33CE, 0x33D7, 0x33DC, 0x33EC, 0x33F8, 0x3402, 0x340F, 0x341B, 
			0x3425, 0x3431, 0x344C, 0x3451, 0x3459, 0x345F, 0x3464, 0x3474, 0x347E, 0x3488, 
			0x348D, 0x3496, 0x34A0, 0x34AC, 0x34C7, 0x34CC, 0x34D4, 0x34DA, 0x34DF, 0x34EF, 
			0x34F9, 0x3503, 0x3508, 0x3511, 0x351B, 0x353F,
		};
	
		static void BatchIt(int addr, int opcode) {
			int current = address + addr + 2;
			
			if(romData[current - 2] != opcode || (romData[current] & ~OR) >= 0x20) {
				if(error())return;
			}
			
			romData[current] |= OR;
		}
		
		static void patch() {
			patch(-1);
		}
		
		static void patch(int opcode){
			if(opcode==-1) switch(romData[address]&15){
				case 0x9:
					if(romData[address] == 0xB9) break;
					//if(romData[address] == 0xF9) break;
					goto default;
				
				case 0xC:
					if(romData[address] == 0x5C) goto default;
					break;
					
				case 0xD:
				case 0xE:
					break;
					
				default:
					Console.WriteLine("{0:X6}", address);
					if(error()) return;
					break;
			}
			else if(opcode!=romData[address]){
				if(error()) return;
			}
		
			if((romData[address+2] & ~OR) >= 0x20) {
				Console.WriteLine("kabum");
				if(error()) return;
			}
			
			romData[address+2] |= OR;
		
			//BatchIt(0, romData[address]);
			address += 3;
		}
		
		static bool error() {
			if(silency)return true;
			Console.WriteLine("Fatal Error: invalid opcode or command detected.");
			Console.WriteLine("Or you're not using lastest version of Lunar Magic");
			Console.WriteLine("or this program is outdated!");
			pause();
			throw new Exception();
			Environment.Exit(1);
			return false;
		}
		
		static int read3() {
			return romData[address++] | (romData[address++] << 8) | (romData[address++] << 16);
		}
		
		static void set(int a){
			address = FromSA1(a);
		}
		
		static int snes(int pc){
			pc -= header_shift;
		
			int addr = ((pc&0x7f8000)<<1)|(pc&0x7fff)|0x8000;
			
			return addr>=0x400000?addr+0x400000:addr;
		}
		
		static int ToPC(int snes) {
			return  ((snes & 0x7f0000) >> 1) | (snes & 0x7fff);
		}
		
		static int header(int pc) { return pc += header_shift; }
		
		static int FromSA1(int snes) {
			if(snes>=0x800000)snes-=0x400000;
			return header(ToPC(snes));
		}
		
		static void pause() {
			Console.Write("Press any key to continue...");
			Console.ReadKey(true);
			Console.WriteLine();
		}
		
		static bool silency = false;
		static int header_shift = 0x200;
		static byte[] romData;
		static int address;
		static byte OR = 0x60;
	
		static void smkdanvram() {
			int offset = 0x003E2;
			
			if(romData[offset] == 0xF0) {
				if (!silency) Console.WriteLine("VRAM Patch not found.");
				return;
			}
			else if (!silency) {
				Console.WriteLine("Fixing VRAM Patch...");
			}
			
			address = romData[offset+1] | (romData[offset+2] << 8) | (romData[offset+3] << 16);
			address = FromSA1(address);
			address -= 0x242E;
			
			int current = 0, cnt = 0;
			
			foreach(ushort item in smkdan) {
				current = item + address + 2;
				
				switch(romData[current - 2] & 15) {
					case 0xC:
						if(romData[current - 2] == 0x5C) goto default;
						break;
						
					case 0xD:
					case 0xE:
						break;
						
					default:
						if(error())continue;
						return;
				}
				
				if(romData[current] >= 0x20) {
					if((romData[current] & ~0x60) < 0x1f) { continue; }
					
					if(error())continue;
					return;
				}
				
				romData[current] |= (byte)0x60;
				++cnt;
			}
			
			// static void BatchIt(ref byte[] romData, int addr, int opcode)
			
			// L1 stuff
			// 1F/B2C8:	A9E61B  	LDA #$1BE6
			// 1F/B2E0:	A9E61B  	LDA #$1BE6
			// 1F/B331:	A9E61B  	LDA #$1BE6
			
			// 1F/B2F8:	A9661C  	LDA #$1C66
			// 1F/B313:	A9661C  	LDA #$1C66
			// 1F/B354:	A9661C  	LDA #$1C66
			
			// L2 stuff
			// 1F/B386:	A9E81C  	LDA #$1CE8
			// 1F/B39E:	A9E81C  	LDA #$1CE8
			// 1F/B3EF:	A9E81C  	LDA #$1CE8
			
			// 1F/B3B6:	A9681D  	LDA #$1D68
			// 1F/B3D1:	A9681D  	LDA #$1D68
			// 1F/B412:	A9681D  	LDA #$1D68
			
			BatchIt(0x32C8, 0xA9); // Fix DMA stuff (L1)
			BatchIt(0x32E0, 0xA9);
			BatchIt(0x3331, 0xA9);
			BatchIt(0x32F8, 0xA9);
			BatchIt(0x3313, 0xA9);
			BatchIt(0x3354, 0xA9);
			BatchIt(0x3386, 0xA9); // L2
			BatchIt(0x339E, 0xA9);
			BatchIt(0x33EF, 0xA9);
			BatchIt(0x33B6, 0xA9);
			BatchIt(0x33D1, 0xA9);
			BatchIt(0x3412, 0xA9);
			BatchIt(0x3572, 0xA0); // Fixes a bug about MVN
			OR = 0x30; BatchIt(0x27CD, 0xA9); // Fixes Direct Page
			OR = 0x60; BatchIt(0x25D9, 0xA9);
		}
	
		static void lunarmagic() {
			if(!silency) Console.WriteLine("Fixing LM code...");
		
			set(0x03BB00);
			patch();
			patch();
			patch();
			patch();
			set(0x05DC50);
			patch();
			set(0x05DC57);
			patch();
			set(0x05DC5F);
			patch();
			set(0x05DC68);
			patch();
			set(0x05DC6F);
			patch();
			patch();
			set(0x05DC83);
			patch();
			patch();
			set(0x05DD00);
			patch();
			set(0x05DD17);
			patch();
			set(0x05DD31);
			patch();
			set(0x05DD3A);
			patch();
			patch();
			set(0x06F578);
			patch();
			set(0x06F58D);
			patch();
			set(0x06F59F);
			patch();
			set(0x0DFEAC);
			patch();
			set(0x0DFEC0);
			patch();
			set(0x0DFEF2);
			patch();
			//set(0x0DFF1D);
			//patch();
			set(0x0DFF28);
			patch();
			set(0x0EFD33);
			patch();
			set(0x06F609);
			patch();
			set(0x06F61A);
			patch();
			set(0x06F631);
			patch();
			OR = 0x30;
			set(0x058E12);
			patch();
			set(0x058DB1);
			patch();
			set(0x058DB9);
			patch();
			OR = 0x60;
			
			set(0x00AF71); if(romData[address]==0x22) {
				set(0x00AF72); set(read3());
				//if(!silency) Console.WriteLine("Applying fixes on freespace address ${0:X6}", snes(address));
				
				patch(); patch(); patch(); patch();
				patch(); patch(); patch(); patch();
				patch(); patch(); patch(); patch();
				patch(); patch(); patch(); patch();
				patch(); patch();
			}
			
			// Music bypass
			set(0x0DF136); if(romData[address]==0xDA) {
				if(!silency) Console.WriteLine("Fixing Music Bypass...");
				set(0x0DF135);
				patch();
				set(0x0DF13D);
				patch();
			}
			
			// Timer bypass
			set(0x0DF170); if(romData[address]==0x33) {
				if(!silency) Console.WriteLine("Fixing Timer Bypass...");
				
				set(0x0DF166);
				patch();
				
				set(0x0DF16F);
				patch();
				set(0x0DF178);
				patch();
				set(0x0DF17F);
				patch();
			}
			
			// ExAnimation
			set(0x95B8); if(romData[address]!=0x05) {
				set(0x95B6); int i = read3()-0x4B8;
				set(i);
				
				if(romData[address]==0x53) { // RATS
					set(i+0x884);
					
					if(romData[address]==0xBF){
						if(!silency) Console.WriteLine("Fixing ExAnimation...");
					
						// current ROM test address: $1282FC 'S' .. TAR						
//$12/8BE1 8F 01 07 00 STA $000701[$00:0701]   A:3942 X:002C Y:0003 D:6000 DB:7F S:01F1 P:envmxdizc HC:0626 VC:120 FC:48 I:00
//$12/8BE5 8F 03 09 00 STA $000903[$00:0903]   A:3942 X:002C Y:0003 D:6000 DB:7F S:01F1 P:envmxdizc HC:0682 VC:120 FC:48 I:00

						set(i-0x1282FC+0x128BE1+2);
						romData[address] |= 0x60;
						set(i-0x1282FC+0x128BE5+2);
						romData[address] |= 0x60;
						
/*$12/8AE9 69 05 09    ADC #$0905              A:0046 X:0046 Y:0000 D:6000 DB:7F S:01F1 P:envmxdizc HC:1076 VC:120 FC:17 I:00
$12/8AEC 99 C4 C0    STA $C0C4,y[$7F:C0C4]   A:094B X:0046 Y:0000 D:6000 DB:7F S:01F1 P:envmxdizc HC:1108 VC:120 FC:17 I:00
$12/8AEF 06 08       ASL $08    [$00:6008]   A:094B X:0046 Y:0000 D:6000 DB:7F S:01F1 P:envmxdizc HC:1162 VC:120 FC:17 I:00
$12/8AF1 65 08       ADC $08    [$00:6008]   A:094B X:0046 Y:0000 D:6000 DB:7F S:01F1 P:envmxdizc HC:1224 VC:120 FC:17 I:00
$12/8AF3 8B          PHB                     A:0953 X:0046 Y:0000 D:6000 DB:7F S:01F1 P:envmxdizc HC:1264 VC:120 FC:17 I:00
$12/8AF4 48          PHA                     A:0953 X:0046 Y:0000 D:6000 DB:7F S:01F0 P:envmxdizc HC:1294 VC:120 FC:17 I:00
$12/8AF5 8A          TXA                     A:0953 X:0046 Y:0000 D:6000 DB:7F S:01EE P:envmxdizc HC:1332 VC:120 FC:17 I:00
$12/8AF6 69 03 07    ADC #$0703              A:0046 X:0046 Y:0000 D:6000 DB:7F S:01EE P:envmxdizc HC:1354 VC:120 FC:17 I:00
$12/8AF9 65 08       ADC $08    [$00:6008]   A:0749 X:0046 Y:0000 D:6000 DB:7F S:01EE P:envmxdizc HC:0022 VC:121 FC:17 I:00
$12/8AFB AA          TAX                     A:0751 X:0046 Y:0000 D:6000 DB:7F S:01EE P:envmxdizc HC:0062 VC:121 FC:17 I:00
$12/8AFC BF 00 00 7E LDA $7E0000,x[$7E:0751] A:0751 X:0751 Y:0000 D:6000 DB:7F S:01EE P:envmxdizc HC:0084 VC:121 FC:17 I:00
$12/8B00 48          PHA                     A:5555 X:0751 Y:0000 D:6000 DB:7F S:01EE P:envmxdizc HC:0140 VC:121 FC:17 I:00
$12/8B01 9B          TXY                     A:5555 X:0751 Y:0000 D:6000 DB:7F S:01EC P:envmxdizc HC:0178 VC:121 FC:17 I:00
$12/8B02 CA          DEX                     A:5555 X:0751 Y:0751 D:6000 DB:7F S:01EC P:envmxdizc HC:0200 VC:121 FC:17 I:00
$12/8B03 C8          INY                     A:5555 X:0750 Y:0751 D:6000 DB:7F S:01EC P:envmxdizc HC:0222 VC:121 FC:17 I:00
$12/8B04 A5 08       LDA $08    [$00:6008]   A:5555 X:0750 Y:0752 D:6000 DB:7F S:01EC P:envmxdizc HC:0244 VC:121 FC:17 I:00
$12/8B06 3A          DEC A                   A:0008 X:0750 Y:0752 D:6000 DB:7F S:01EC P:envmxdizc HC:0284 VC:121 FC:17 I:00
$12/8B07 44 7E 7E    MVP 7E 7E               A:0007 X:0750 Y:0752 D:6000 DB:7F S:01EC P:envmxdizc HC:0306 VC:121 FC:17 I:00
$12/8B0A 68          PLA                     A:FFFF X:0748 Y:074A D:6000 DB:7E S:01EC P:envmxdizc HC:0826 VC:121 FC:17 I:00
$12/8B0B 9D 01 00    STA $0001,x[$7E:0749]   A:5555 X:0748 Y:074A D:6000 DB:7E S:01EE P:envmxdizc HC:0870 VC:121 FC:17 I:00
$12/8B0E FA          PLX                     A:5555 X:0748 Y:074A D:6000 DB:7E S:01EE P:envmxdizc HC:0924 VC:121 FC:17 I:00
$12/8B0F BD 00 00    LDA $0000,x[$7E:0953]   A:5555 X:0953 Y:074A D:6000 DB:7E S:01F0 P:envmxdizc HC:0968 VC:121 FC:17 I:00
$12/8B12 48          PHA                     A:5555 X:0953 Y:074A D:6000 DB:7E S:01F0 P:envmxdizc HC:1022 VC:121 FC:17 I:00
$12/8B13 9B          TXY                     A:5555 X:0953 Y:074A D:6000 DB:7E S:01EE P:envmxdizc HC:1060 VC:121 FC:17 I:00
$12/8B14 CA          DEX                     A:5555 X:0953 Y:0953 D:6000 DB:7E S:01EE P:envmxdizc HC:1082 VC:121 FC:17 I:00
$12/8B15 C8          INY                     A:5555 X:0952 Y:0953 D:6000 DB:7E S:01EE P:envmxdizc HC:1104 VC:121 FC:17 I:00
$12/8B16 A5 08       LDA $08    [$00:6008]   A:5555 X:0952 Y:0954 D:6000 DB:7E S:01EE P:envmxdizc HC:1126 VC:121 FC:17 I:00
$12/8B18 3A          DEC A                   A:0008 X:0952 Y:0954 D:6000 DB:7E S:01EE P:envmxdizc HC:1166 VC:121 FC:17 I:00
$12/8B19 44 7E 7E    MVP 7E 7E               A:0007 X:0952 Y:0954 D:6000 DB:7E S:01EE P:envmxdizc HC:1188 VC:121 FC:17 I:00
$12/8B1C 68          PLA                     A:FFFF X:094A Y:094C D:6000 DB:7E S:01EE P:envmxdizc HC:0304 VC:122 FC:17 I:00
$12/8B1D 9D 01 00    STA $0001,x[$7E:094B]   A:5555 X:094A Y:094C D:6000 DB:7E S:01F0 P:envmxdizc HC:0348 VC:122 FC:17 I:00
$12/8B20 AB          PLB                     A:5555 X:094A Y:094C D:6000 DB:7E S:01F0 P:envmxdizc HC:0402 VC:122 FC:17 I:00
$12/8B21 60          RTS                     A:5555 X:094A Y:094C D:6000 DB:7F S:01F1 P:envmxdizc HC:0438 VC:122 FC:17 I:00*/

						set(i-0x1282FC+0x128AE9);
						patch(0x69);
						set(i-0x1282FC+0x128AF6);
						patch(0x69);
						set(i-0x1282FC+0x128B07+1);
						romData[address]=0;
						romData[address+1]=0;
						set(i-0x1282FC+0x128B19+1);
						romData[address]=0;
						romData[address+1]=0;
						set(i-0x1282FC+0x128AFC+3);
						romData[address]=0;
						
/*$10/8D12 AF AD 14 7E LDA $7E14AD[$7E:14AD]   A:1C02 X:0002 Y:0000 D:3000 DB:7F S:1FEE P:envMXdizc HC:0686 VC:198 FC:45 I:00*/

						set(i-0x108424+0x108D12+3);
						romData[address]=0x40;
						
						set(i+0x884+1); // LDA $000000,x
						romData[address]=0;
						romData[address+1]=0;
						romData[address+2]=0;
						set(i+0x88e); // MVN $00,$00
						romData[address] = 0x54;
						romData[address+1] = 0;
						romData[address+2] = 0;
						set(i+0x89f); // MVN $00,$00
						romData[address] = 0x54;
						romData[address+1] = 0;
						romData[address+2] = 0;
						
						set(i+0x880  ); patch(0x69);
						set(i+0x877  ); patch(0x69);
						set(i+0x4df  ); patch(); patch(); patch();
						set(i+0x162  ); patch(); patch(); patch();
						set(i+0x16d  ); patch();
						set(i+0x1c9  ); patch();
						set(i+0x1a3  ); patch();
						set(i+0x1ab  ); patch();
						set(i+0x1b5  ); patch();
						set(i+0x1c2  ); patch();
						set(i+0x438+1); romData[address] = 0x483-0x438-2; // BEQ $XX
						set(i+0x483  ); OR = 0x30; patch(0xA9); OR = 0x60;
						set(i+0x191  ); patch();
						set(i+0x199  ); patch();
					}
				}
			}
			
			set(0xA5E1+2); if(romData[address]==0x22) {
				set(0xA5E1+3); set(read3());
				patch();
			}
			
			/*org $10824C ; 72 bytes
			;RATS of length 0x0040.
			org $108254 ; 64 bytes
			;before - empty!
			;currentlly
			db $AD,$BE,$13,$C9,$03,$F0,$0A,$B9,$F8,$19,$1F,$05,$C0,$00,$99,$F8,$19,$6B,$FF,$FF,$FF,$FF,$FF,$FF
			db $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$AD,$BE,$13,$C9,$03,$F0,$05,$A4,$0E,$B1,$08,$6B,$A9,$00,$6B,$4C
			db $4D,$00,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
			;current dissembly:
			108254: LDA $13BE
			108257: CMP #$03
			108259: BEQ $8265
			10825B: LDA $19F8,Y
			10825E: ORA $00C005,X
			108262: STA $19F8,Y
			108265: RTL 
			108266: SBC $FFFFFF,X
			10826A: SBC $FFFFFF,X
			10826E: SBC $FFFFFF,X
			108272: SBC $BEADFF,X
			108276: ORA ($C9,S),Y
			108278: ORA $F0,S
			10827A: ORA $A4
			10827C: ASL $08B1
			10827F: RTL 
			108280: LDA #$00
			108282: RTL 
			108283: JMP $004D
			108286: ORA ($FF,X)
			108288: SBC $FFFFFF,X
			10828C: SBC $FFFFFF,X
			108290: SBC $FFFFFF,X*/
			
			// Item Index 03 No Track
			set(0xC058); if(romData[address]==0x22) {
				if(!silency) Console.WriteLine("Fixing Memory Index 03 No Track...");
				
				set(0xC058+1); int i = read3();
				
				set(i);
				patch();
				set(0x10825B-0x108254+i);
				patch();
				set(0x108262-0x108254+i);
				patch(0x99);
				set(0x108274-0x108254+i);
				patch();
			}
			
			// Custom Palettes
			set(0x0EF5A9);
			if(romData[address+1]==1){
				if(!silency) Console.WriteLine("Fixing Custom Palettes Hack...");
				
				patch(0x99);
				set(0x0EF5BA);
				patch(0x99);
				set(0x0EF5BF);
				patch(0x99);
			}
			
			// ExGFX
			// note to self: using a bunch of IF to make sure that the GFX hijack is really installed instead of original game.
			set(0xab15);
			if(romData[address+1]==0xb2) {
				patch();
				set(0xab2b);
				if(romData[address+1]==0xb2) {
					patch();
					set(0x0ff79b);
					if(romData[address+1]==5) {
						if(!silency) Console.WriteLine("Fixing ExGFX Hack...");
						
						patch();
						set(0x0ff82c);
						patch();
					}
				}
			}
		}
	
		static void Main(string[] args) {
			if (args.Length == 1)
			{
				goto continue_fix;
			}
			if (args.Length==2 && args[1] == "-s")
			{
				silency = true;
				goto continue_fix;
			}
		
			Console.WriteLine("usage: lunarfix romfile");
			Console.WriteLine("write -s after romfile to use ABSOLUTE SILENCY!");
			pause();
			return;
			
		continue_fix:
			romData = File.ReadAllBytes(args[0]);
			
			if(romData.Length < 1024*1024)
			{
				if (!silency)
				{
					Console.WriteLine("This ROM looks too small. Please expand it.");
					pause();
				}
				return;
			}
			
			if (romData.Length % 0x8000 != 512)
			{
				if (romData.Length % 0x8000 == 0)
				{
					header_shift = 0;
				}
				else if (!silency)
				{
					Console.WriteLine("Fatal Error: Invalid ROM align!");
					pause();
					return;
				}
				else
				{
					return;
				}
			}
			
			smkdanvram();
			lunarmagic();
			
			File.WriteAllBytes(args[0], romData);
			
			if(!silency) 
			{
				Console.WriteLine("RAM addresses have been successful remapped.");
				pause();
			}
		}
	}
}