===================
= SA-1 Pack v1.00 =
===================

Current Package:
	- SA-1 Patch v1.10
	- The Last Remapper v1.00
	- Magic Sprites Patch v1.00
	- Lunar Fix v1.00

SA-1 Pack is a pack of patches and tools that allows to you extract the best of SA-1.
Though it's 100% incompatible with everything, isn't not possible to make it compatible.


HOW TO USE:
	- Apply sa1.asm with Asar
	- Apply lastremap.asm with Asar
	- Apply sprites.asm with Asar
	- Apply others patches that can only be inserted on a clean ROM, for example INIT.ASM from AMM.
	- Save a level on Lunar Magic
	- Run LunarFix [name of you rom]

HOW TO USE LUNAR MAGIC CORRECTLLY:

If you're editing something by first time, i.e bypass, custom palettes, ExGFX, Exanimation, etc.,
make sure to run LunarFix to fix all these ASM Hacks, or you ROM will garbare up.

Also make sure to run Lunar Fix every time that you insert *NEW or EDITED* ExGFX. This is important.

And every 50 saves run Lunar Fix to make sure that all will work correctlly.

================
= PATCHES LIST =
================

SA-1 Patch v1.10:
	The last version of SA-1 installer. Now much more stable, faster and useful.
	REQUIRES The Last Remapper v1.00+ or your ROM will die!

The Last Remapper v1.00:
	This is a amazing patch that will move all RAM at $7E:0000-$7E:1FFF ($0000-$1FFF)
	to $40:0000-$40:1FFF ($6000-$7FFF). ONLY APPLY THIS PATCH ONCE! IF YOU APPLY THIS PATCH
	AFTER EDITING WITH ANYTHING BAD THINGS WILL APPENDS! THIS PATCH REQUIRES SA-1!

Magic Sprites Patch v1.00:
	This patch will moves the SMW's Sprite Engine to SA-1 side. Please note that
	this requires both SA-1 and The Last Remapper obvious. Also requires 512 bytes
	of FreeBWRAM.

	This patch will cutdown slowdown by ~300%, unless if sprites isn't doing any slowdown,
	but anything else.

==============
= TOOLS LIST =
==============

LunarFix v1.00:
	This tool fixes the Lunar Magic's RAM mapping. Currentlly it fixes:
		- Levels
		- Music Bypass
		- Timer Bypass
		- Item Memory Index 3 No Track
		- ExGFX hack
		- VRAM Patch (gfx+2)
		- ExAnimation ***
		- Custom Palettes

	But it doesn't fix these:
		- Overworld
		- Anything else.

***: ExAnimation support is PRETTY LIMITED. Use at own risk.

=================
= API Functions =
=================

$008A58: Dynamic Bank Allocation - This allows to you switch banks to a specific
	ROM area using PC addresses.

	Input:
		X = PC address >> 16;
	
	Returns:
		X = Bank Byte

	Destroys:
		Accum and X/Y

$008A5C: Reset Bank Allocation - This will reset bank switch settings. Use it after running your
	routine that handle with bank switching.

	Input:
		Nothing

	Returns:
		Nothing

	Destroys:
		Accum
